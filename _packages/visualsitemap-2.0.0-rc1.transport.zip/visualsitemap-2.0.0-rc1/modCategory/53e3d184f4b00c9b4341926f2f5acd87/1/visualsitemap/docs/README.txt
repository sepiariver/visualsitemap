# visualSitemap

A Visual Sitemap Generator: Perfect for pre-design work and getting client signoffs.

visualSitemap uses Wayfinder to replicate your Resource Tree in a nicely styled, HTML/CSS sitemap with clickable links.  Get a jump on development as well, because the Resource Tree will already be populated with the site's architecture ;)

Uses [SlickMap CSS by Matt Everson of Astuteo](http://astuteo.com/slickmap)

(He's an EE guy, but donate to show him how awesome the MODX community is ;) - and to let him know you appreciate his work!